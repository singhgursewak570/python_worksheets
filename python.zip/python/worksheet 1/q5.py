n=input("ENTER VALUE OF N \n")
nn=n+n
nnn=n+n+n
n=int(n)
nn=int(nn)
nnn=int(nnn)
sum=n+nn+nnn
print("VALUE : ",sum)