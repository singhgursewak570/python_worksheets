first= input("ENTER FIRST NAME \n")
last= input("ENTER LAST NAME \n")
print(last," ",first)