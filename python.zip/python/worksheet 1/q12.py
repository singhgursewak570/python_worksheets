a1=int(input("ENTER ANGLE 1"))
a2=int(input("ENTER ANGLE 2"))
a3=int(input("ENTER ANGLE 3"))
if a1+a2+a3==180:
    print("IT CAN FORM A TRIANGLE")
else:
    print("IT CANNOT FORM A TRIANGLE")