n=int(input("ENTER YEAR \n"))
if n%4 ==0 :
    print("YEAR IS LEAP \n")
else:
    print("YEAR IS NOT LEAP")