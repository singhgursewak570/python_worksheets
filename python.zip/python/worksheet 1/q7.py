n=int(input("ENTER CELSIUS \n"))
n=(n*1.8)+32
print("FEHRENHEIT : ",n)