import math
x1=int(input("ENTER x1 \n"))
y1=int(input("ENTER y1 \n"))
x2=int(input("ENTER x2 \n"))
y2=int(input("ENTER y2 \n"))
dist=math.sqrt((y2-y1)+(x2-x1))
print("DISTANCE : ",dist)