n1=int(input("ENTER FIRST NUMEBR"))
n2=int(input("ENTER SECOND NUMEBR"))
t=n1
n1=n2
n2=t
print("n1 : ",n1)
print("n2 : ",n2)