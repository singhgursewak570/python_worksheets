n=int(input("ENTER RADIUS OF CIRCLE \n"))
area = 3.14*n*n
print("AREA : ",area)