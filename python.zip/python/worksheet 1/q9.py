n=int(input("ENTER NUMBER \n"))
if n%2==0 :
    print("NUMBER IS EVEN \n")
else:
    print("NUMBER IS ODD")