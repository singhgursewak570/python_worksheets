# Q15
class StringClass:
    def get_String(self):
        self.s = input("Enter string: ")

    def print_String(self):
        print(self.s.upper())

sc = StringClass()
# sc.get_String()
# sc.print_String()

