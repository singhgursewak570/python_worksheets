# Q8
def student(name, age, course):
    print(student.__code__.co_varnames)

student("Ram", 20, "CSE")
