# Q7
def robot():
    def move():
        print("Moving")
    move()

robot()
