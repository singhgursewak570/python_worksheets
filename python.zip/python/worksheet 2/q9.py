L = [10,23,45,50,77,90]
for x in L:
    if x % 5 == 0:
        print(x)
