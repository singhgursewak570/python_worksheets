exam_st_date = (11,12,2025)
print("The examination will start from:", exam_st_date[0], "/", exam_st_date[1], "/", exam_st_date[2])
