L = [2, 4, 6, 8]

s = 0
for x in L:
    s = s + x

print("SUM:", s)
