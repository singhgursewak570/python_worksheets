L = [2, 4, 6, 8]

m = 1
for x in L:
    m = m * x

print("MUL:", m)
