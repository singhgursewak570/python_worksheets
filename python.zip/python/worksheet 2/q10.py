n = 7
b = (n % 2 == 0)
if b == True:
    print("EVEN")
else:
    print("ODD")
