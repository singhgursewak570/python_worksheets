data = {1:2.3, 2:4.5, 3:1.8, 4:3.6}
for k in data:
    if data[k] > 3.0:
        print(k)
