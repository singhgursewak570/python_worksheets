pos = [(2,3),(4,5),(6,7),(7,8)]
for p in pos:
    if p[0] % 2 == 0:
        print(p)
